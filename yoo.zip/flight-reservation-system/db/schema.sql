-- Flight Reservation System schema (MySQL)
CREATE DATABASE IF NOT EXISTS flight_reservation;
USE flight_reservation;

DROP TABLE IF EXISTS ticket;
DROP TABLE IF EXISTS booking;
DROP TABLE IF EXISTS flight;
DROP TABLE IF EXISTS user;

CREATE TABLE user (
  user_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role VARCHAR(50) NOT NULL
);

CREATE TABLE flight (
  flight_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  flight_number VARCHAR(50) UNIQUE NOT NULL,
  source VARCHAR(50) NOT NULL,
  destination VARCHAR(50) NOT NULL,
  departure_time VARCHAR(50) NOT NULL,
  arrival_time VARCHAR(50) NOT NULL,
  capacity INT NOT NULL DEFAULT 20,
  price_per_seat DOUBLE NOT NULL
);

CREATE TABLE booking (
  booking_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  booking_date DATE NOT NULL,
  journey_date DATE NOT NULL,
  seats INT NOT NULL,
  total_price DOUBLE NOT NULL,
  status VARCHAR(50) NOT NULL,
  flight_id BIGINT NOT NULL,
  user_id BIGINT NOT NULL,
  FOREIGN KEY (flight_id) REFERENCES flight(flight_id),
  FOREIGN KEY (user_id) REFERENCES user(user_id)
);

CREATE TABLE ticket (
  pnr_no BIGINT AUTO_INCREMENT PRIMARY KEY,
  passenger_name VARCHAR(50) NOT NULL,
  gender VARCHAR(50) NOT NULL,
  age INT NOT NULL,
  journey_date DATE NOT NULL,
  seat_no VARCHAR(20) NOT NULL,
  booking_id BIGINT NOT NULL,
  status VARCHAR(50) NOT NULL,
  FOREIGN KEY (booking_id) REFERENCES booking(booking_id)
);

-- Sample flights so the app has data to search/book against out of the box
INSERT INTO flight (flight_number, source, destination, departure_time, arrival_time, capacity, price_per_seat) VALUES
('AI101', 'Bangalore', 'Hyderabad', '10:49', '20:49', 20, 5000.0),
('IN201', 'Bangalore', 'Hyderabad', '18:41', '20:41', 20, 5000.0),
('AI304', 'Bangalore', 'Hyderabad', '11:25', '11:27', 20, 5600.0),
('6E505', 'Delhi', 'Mumbai', '06:00', '08:15', 20, 4500.0),
('SG220', 'Mumbai', 'Chennai', '14:30', '16:45', 20, 3900.0);
