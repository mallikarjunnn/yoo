# Memory.md — Progress Log

## Current Status
- **Phase in progress:** None — built end-to-end in one pass per user request.
- **Last completed phase:** All 8 milestones (Home/Search, Auth, Booking flow, Admin, User Dashboard, Global Exception Handling, Unit Tests). Milestone 8 (push to GitHub) is left to the user.

## Decisions & Assumptions Log

- **Password storage (changed on explicit request):** Originally hashed with SHA-256.
  The project owner explicitly asked for this to be reverted so passwords stay directly
  readable in the `user` table (no password-reset flow needed, and lookups are simple
  for a support/admin need). Passwords are now stored and compared as plain text in
  `UserService`. This was flagged as a real security trade-off before making the change
  (anyone with DB access can read every user's password, and reused passwords elsewhere
  become exposed too) - it's a deliberate, informed decision for this local training
  prototype, not an oversight. If this project is ever pointed at real user data or
  deployed anywhere reachable by others, this should be the first thing reverted back
  to hashing (or a real auth library) before that happens.
- **Per-ticket cancellation:** a multi-passenger booking can now cancel individual
  tickets (`POST /user/bookings/{id}/tickets/{pnrNo}/cancel`) without touching the
  other passengers' seats. Seat availability (`FlightDao.getBookedSeats`) is computed
  by counting non-cancelled tickets, not by summing `booking.seats`, so a partial
  cancellation correctly frees just those seats. The booking only flips to CANCELLED
  once every ticket on it is cancelled. "Cancel all" on My Bookings still cancels the
  whole booking at once for convenience.
- **Container-level error pages:** added a minimal `web.xml` (justified under Rules.md's
  "unavoidable" exception) purely for `<error-page>` mappings, since that has no
  Java-config equivalent. This catches anything that could otherwise surface as a raw
  Tomcat/Jasper stack-trace page (e.g. an exception thrown during JSP rendering itself,
  which `@ControllerAdvice` cannot intercept) and shows the app's own styled error page
  instead. `AuthController.login()` also has a defensive catch-all so any unexpected
  runtime error during login shows the same friendly "couldn't log you in" message
  rather than propagating.
- **Visual redesign (post-launch, on request):** the UI was intentionally redesigned
  away from the brief's literal wireframe styling into an original "departure board /
  boarding pass" identity (dark navy + amber, Space Grotesk + IBM Plex Mono, a
  boarding-pass component for tickets/confirmation, a literal dark departure-board
  panel for search results and the admin View Flights screen) with a persisted
  dark/light toggle in the navbar. All emoji glyphs were replaced with small inline
  SVG line icons for a more considered look. This was an explicit, deliberate
  departure from Design.md's original brief, requested by the project owner.
- **Currency symbol:** The brief's wireframes use `$` on Search Results and `₹` on Add
  Flight — treated as inconsistent template artifacts. Standardized on `$` everywhere.
- **Seat numbering:** No seat-selection UI is specified, so seats are auto-assigned
  sequentially per flight+date (`A1`, `A2`, `A3`, ...) at booking time.
- **Multi-step booking flow (Booking Form -> Add Passenger x N -> Confirmation):**
  implemented with a plain in-session Java object (`controller/PendingBooking.java`),
  not persisted to the DB, so a half-finished booking never reaches the database. Only
  the finished booking + tickets are written, inside a single `@Transactional` method.
- **Session-based auth/roles:** No Spring Security (explicitly disallowed). A single
  `AuthInterceptor` gates `/booking/**`, `/user/**`, `/admin/**` behind a logged-in
  session, and additionally checks role for `/admin/**` vs `/user/**`.
- **"View Flights" grouping:** The admin summary (flight number, journey date, total
  passengers, total bookings, total revenue, days until journey) is grouped by
  **flight + journey date**, not just by flight, to match the wireframe's per-date rows.
  Only flight/date combinations with at least one non-cancelled booking are shown.
- **Extra exceptions beyond the three named in Architecture.md:** Added
  `DuplicateEmailException` and `InvalidCredentialsException` alongside
  `SeatUnavailableException`, `DuplicateFlightNumberException`, and
  `ResourceNotFoundException`, since sign-up/login need equivalent centralized
  handling and the brief's uniqueness/security requirements imply them.
- **Sign up does not auto-login:** matches the wireframe's "Already have an account?
  Login here" link — after signup the user is redirected to `/login` with a success
  message, not straight into a session.
- **Redirect-after-login:** the target URL (e.g. `/booking/new?flightId=12`) is stashed
  in the session by `AuthInterceptor` before bouncing to `/login`, and `AuthController`
  redirects back there once login succeeds — matches "On successful login only, it
  should redirect to the Booking Form Page."

## Phase History

### [Full build — Home/Search/Auth/Booking/Admin/UserDashboard/ExceptionHandling/Tests] — 2026-09-24
- Files added: entire Maven project under `flight-reservation-system/` — `pom.xml`,
  `db/schema.sql`, all `config`, `controller`, `service`, `dao`, `model`, `exception`,
  `interceptor` classes, all 13 JSP views + `error.jsp` + shared header/footer
  fragments, `style.css` (per Design.md palette/typography), `script.js`, and
  `UserServiceTest` / `AuthControllerTest`.
- What works: full search -> login-gated booking -> multi-passenger add -> confirmation
  -> my bookings (view tickets / cancel with seat release) flow for users; add
  flight (with duplicate-number rejection) and view flights (upcoming/completed tabs
  with aggregate stats) for admins; centralized exception handling; unit tests for
  sign up and login.
- Known issues / TODO: not run against a live MySQL instance or a real servlet
  container from this session (no Maven/network access in the build sandbox) — see
  README.md for how to build, seed the DB, and run it locally. Recommend a smoke test
  of the full user + admin flow after first deploy.
- Next: Milestone 8 (push to the user's own GitHub repository) and, optionally,
  Technical Interview/Viva prep on the assumptions above.

- **Session-stored objects made `Serializable`:** `User` and `Ticket` implement
  `java.io.Serializable` (matching `PendingBooking`) since `User` is stored directly in
  `HttpSession` and `Ticket` objects are held inside `PendingBooking` during the
  Add Passenger loop — defensive, in case a servlet container ever persists sessions.
- **Build not verified with Maven/a live container in this session:** this sandbox has
  no internet access to resolve Maven dependencies and no JDK compiler (JRE only), so
  `mvn compile` / `mvn test` could not be run here. Every file was manually reviewed
  line-by-line for correctness (imports, SQL/JDBC parameter binding, EL expressions,
  taglib usage, Spring wiring) instead. Please run `mvn clean test` as your first step
  after downloading — flag anything that doesn't compile and it can be fixed quickly.

## Open Questions
- None blocking. All ambiguities were resolved with the simplest reasonable
  assumption, logged above.
