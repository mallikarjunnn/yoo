package com.flightreservation;

import com.flightreservation.controller.AuthController;
import com.flightreservation.exception.DuplicateEmailException;
import com.flightreservation.exception.InvalidCredentialsException;
import com.flightreservation.interceptor.AuthInterceptor;
import com.flightreservation.model.User;
import com.flightreservation.service.UserService;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

import javax.servlet.http.HttpSession;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Unit tests for Sign Up and Login endpoints (Milestone 7).
 */
public class AuthControllerTest {

    private UserService userService;
    private MockMvc mockMvc;

    @Before
    public void setUp() {
        userService = mock(UserService.class);
        AuthController controller = new AuthController(userService);
        mockMvc = MockMvcBuilders.standaloneSetup(controller)
                .setValidator(new LocalValidatorFactoryBean())
                .build();
    }

    @Test
    public void signupForm_showsSignupView() throws Exception {
        mockMvc.perform(get("/signup"))
                .andExpect(status().isOk())
                .andExpect(view().name("signup"))
                .andExpect(model().attributeExists("user"));
    }

    @Test
    public void signup_withValidData_redirectsToLogin() throws Exception {
        when(userService.signUp(any(User.class))).thenAnswer(inv -> inv.getArgument(0));

        mockMvc.perform(post("/signup")
                        .param("email", "newuser@example.com")
                        .param("password", "password1")
                        .param("role", "User"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"));

        verify(userService).signUp(any(User.class));
    }

    @Test
    public void signup_withBlankEmail_returnsFormWithErrors() throws Exception {
        mockMvc.perform(post("/signup")
                        .param("email", "")
                        .param("password", "password1")
                        .param("role", "User"))
                .andExpect(status().isOk())
                .andExpect(view().name("signup"))
                .andExpect(model().attributeHasFieldErrors("user", "email"));

        verify(userService, never()).signUp(any(User.class));
    }

    @Test
    public void signup_withDuplicateEmail_returnsFormWithFieldError() throws Exception {
        when(userService.signUp(any(User.class)))
                .thenThrow(new DuplicateEmailException("An account with this email already exists."));

        mockMvc.perform(post("/signup")
                        .param("email", "taken@example.com")
                        .param("password", "password1")
                        .param("role", "User"))
                .andExpect(status().isOk())
                .andExpect(view().name("signup"))
                .andExpect(model().attributeHasFieldErrors("user", "email"));
    }

    @Test
    public void loginForm_showsLoginView() throws Exception {
        mockMvc.perform(get("/login"))
                .andExpect(status().isOk())
                .andExpect(view().name("login"));
    }

    @Test
    public void login_withValidCredentials_redirectsToDashboardAndSetsSession() throws Exception {
        User user = new User();
        user.setUserId(1L);
        user.setEmail("valid@example.com");
        user.setRole("User");
        when(userService.login("valid@example.com", "correctPass")).thenReturn(user);

        MockHttpSessionHolder holder = new MockHttpSessionHolder();
        mockMvc.perform(post("/login")
                        .param("email", "valid@example.com")
                        .param("password", "correctPass"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/dashboard"))
                .andDo(result -> holder.session = (HttpSession) result.getRequest().getSession());

        assertNotNull(holder.session.getAttribute(AuthInterceptor.SESSION_USER));
    }

    @Test
    public void login_withInvalidCredentials_returnsLoginViewWithError() throws Exception {
        when(userService.login(eq("wrong@example.com"), anyString()))
                .thenThrow(new InvalidCredentialsException("Invalid email or password."));

        mockMvc.perform(post("/login")
                        .param("email", "wrong@example.com")
                        .param("password", "whatever"))
                .andExpect(status().isOk())
                .andExpect(view().name("login"))
                .andExpect(model().attributeExists("loginError"));
    }

    /** Small mutable holder so the andDo(...) lambda can capture the session. */
    private static class MockHttpSessionHolder {
        HttpSession session;
    }
}
