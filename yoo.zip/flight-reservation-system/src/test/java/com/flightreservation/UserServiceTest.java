package com.flightreservation;

import com.flightreservation.dao.UserDao;
import com.flightreservation.exception.DuplicateEmailException;
import com.flightreservation.exception.InvalidCredentialsException;
import com.flightreservation.model.User;
import com.flightreservation.service.UserService;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for Sign Up and Login business logic (Milestone 7).
 *
 * Note: passwords are stored as plain text in this project (a deliberate,
 * documented choice - see Memory.md), so these tests assert plain-text
 * persistence and comparison rather than hashing.
 */
public class UserServiceTest {

    private UserDao userDao;
    private UserService userService;

    @Before
    public void setUp() {
        userDao = mock(UserDao.class);
        userService = new UserService(userDao);
    }

    @Test
    public void signUp_succeeds_whenEmailIsNotTaken() {
        User user = new User();
        user.setEmail("alice@example.com");
        user.setPassword("secret123");
        user.setRole("User");

        when(userDao.existsByEmail("alice@example.com")).thenReturn(false);
        when(userDao.save(any(User.class))).thenReturn(1L);

        User saved = userService.signUp(user);

        assertEquals(Long.valueOf(1L), saved.getUserId());
        assertNull("Password should be cleared from the returned in-memory object", saved.getPassword());
        verify(userDao).save(any(User.class));
    }

    @Test
    public void signUp_savesPasswordAsPlainText() {
        User user = new User();
        user.setEmail("bob@example.com");
        user.setPassword("plaintext1");
        user.setRole("User");

        when(userDao.existsByEmail(anyString())).thenReturn(false);
        when(userDao.save(any(User.class))).thenAnswer(invocation -> {
            User passed = invocation.getArgument(0);
            assertEquals("Password is stored as plain text by design in this project",
                    "plaintext1", passed.getPassword());
            return 2L;
        });

        userService.signUp(user);
        verify(userDao).save(any(User.class));
    }

    @Test(expected = DuplicateEmailException.class)
    public void signUp_throwsDuplicateEmailException_whenEmailAlreadyExists() {
        User user = new User();
        user.setEmail("taken@example.com");
        user.setPassword("secret123");
        user.setRole("User");

        when(userDao.existsByEmail("taken@example.com")).thenReturn(true);

        userService.signUp(user);
    }

    @Test
    public void login_succeeds_withCorrectCredentials() {
        User stored = new User();
        stored.setUserId(5L);
        stored.setEmail("carol@example.com");
        stored.setPassword("correctPassword");
        stored.setRole("Admin");

        when(userDao.findByEmail("carol@example.com")).thenReturn(Optional.of(stored));

        User loggedIn = userService.login("carol@example.com", "correctPassword");

        assertEquals("Admin", loggedIn.getRole());
        assertNull(loggedIn.getPassword());
    }

    @Test(expected = InvalidCredentialsException.class)
    public void login_fails_withWrongPassword() {
        User stored = new User();
        stored.setEmail("dave@example.com");
        stored.setPassword("rightPassword");
        stored.setRole("User");

        when(userDao.findByEmail("dave@example.com")).thenReturn(Optional.of(stored));

        userService.login("dave@example.com", "wrongPassword");
    }

    @Test(expected = InvalidCredentialsException.class)
    public void login_fails_whenEmailNotFound() {
        when(userDao.findByEmail("nobody@example.com")).thenReturn(Optional.empty());

        userService.login("nobody@example.com", "whatever");
    }
}
