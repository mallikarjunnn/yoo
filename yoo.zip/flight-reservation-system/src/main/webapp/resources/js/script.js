// Flight Reservation System - shared client-side helpers

function toggleTheme() {
  var html = document.documentElement;
  var current = html.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  var next = current === 'dark' ? 'light' : 'dark';
  html.setAttribute('data-theme', next);
  try { localStorage.setItem('frs-theme', next); } catch (e) { /* storage unavailable, theme just won't persist */ }
}

function showTab(tabName) {
  var panels = ['upcoming', 'completed'];
  panels.forEach(function (name) {
    var panel = document.getElementById('panel-' + name);
    var tab = document.getElementById('tab-' + name);
    if (!panel || !tab) return;
    if (name === tabName) {
      panel.style.display = 'block';
      tab.classList.add('active');
    } else {
      panel.style.display = 'none';
      tab.classList.remove('active');
    }
  });
}
