<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>View Flights - Flight Reservation System</title>
  <%@ include file="fragments/headAssets.jsp" %>
</head>
<body>
<%@ include file="fragments/header.jsp" %>

<div class="page-wrap">
  <div class="card" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;">
    <div>
      <h2 class="page-title mt-0">Flight journey status</h2>
      <p class="page-subtitle mt-0">Current date: ${currentDate}</p>
    </div>
    <a href="${pageContext.request.contextPath}/admin/dashboard" class="btn btn-outline btn-sm">Back to Dashboard</a>
  </div>

  <div class="board mt-2">
    <div class="board-header">
      <h2>Journeys with bookings</h2>
      <span class="board-meta">${currentDate}</span>
    </div>

    <div class="board-tabs-wrap">
      <div class="tabs">
        <a href="#" id="tab-upcoming" class="tab-link active" onclick="showTab('upcoming');return false;">Upcoming (${upcoming.size()})</a>
        <a href="#" id="tab-completed" class="tab-link" onclick="showTab('completed');return false;">Completed (${completed.size()})</a>
      </div>
    </div>

    <div id="panel-upcoming">
      <c:choose>
        <c:when test="${empty upcoming}">
          <div class="empty-state">No upcoming journeys with bookings yet.</div>
        </c:when>
        <c:otherwise>
          <div class="table-scroll">
            <table class="data-table">
              <thead>
                <tr><th>Flight</th><th>Journey Date</th><th>Passengers</th><th>Bookings</th><th>Revenue</th><th>Days Until</th></tr>
              </thead>
              <tbody>
                <c:forEach var="row" items="${upcoming}">
                  <tr>
                    <td><span class="board-flight-no">${row.flightNumber}</span></td>
                    <td class="mono">${row.journeyDate}</td>
                    <td>${row.totalPassengers}</td>
                    <td>${row.totalBookings}</td>
                    <td class="mono"><fmt:formatNumber value="${row.totalRevenue}" type="currency" currencySymbol="$" maxFractionDigits="0"/></td>
                    <td class="mono">${row.daysUntilJourney}d</td>
                  </tr>
                </c:forEach>
              </tbody>
            </table>
          </div>
        </c:otherwise>
      </c:choose>
    </div>

    <div id="panel-completed" style="display:none;">
      <c:choose>
        <c:when test="${empty completed}">
          <div class="empty-state">No completed journeys yet.</div>
        </c:when>
        <c:otherwise>
          <div class="table-scroll">
            <table class="data-table">
              <thead>
                <tr><th>Flight</th><th>Journey Date</th><th>Passengers</th><th>Bookings</th><th>Revenue</th></tr>
              </thead>
              <tbody>
                <c:forEach var="row" items="${completed}">
                  <tr>
                    <td><span class="board-flight-no">${row.flightNumber}</span></td>
                    <td class="mono">${row.journeyDate}</td>
                    <td>${row.totalPassengers}</td>
                    <td>${row.totalBookings}</td>
                    <td class="mono"><fmt:formatNumber value="${row.totalRevenue}" type="currency" currencySymbol="$" maxFractionDigits="0"/></td>
                  </tr>
                </c:forEach>
              </tbody>
            </table>
          </div>
        </c:otherwise>
      </c:choose>
    </div>
  </div>
</div>

<%@ include file="fragments/footer.jsp" %>
</body>
</html>
