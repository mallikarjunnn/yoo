<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sign Up - Flight Reservation System</title>
  <%@ include file="fragments/headAssets.jsp" %>
</head>
<body>
<%@ include file="fragments/header.jsp" %>

<div class="page-wrap" style="max-width:460px;">
  <div class="card">
    <h2 class="page-title">Sign Up</h2>
    <p class="page-subtitle">Create an account to search, book, and manage flights.</p>

    <form:form modelAttribute="user" method="post" action="${pageContext.request.contextPath}/signup">
      <div class="form-group">
        <label for="email">Email</label>
        <form:input path="email" id="email" cssClass="form-control" placeholder="Enter your email"/>
        <form:errors path="email" cssClass="field-error"/>
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <form:password path="password" id="password" cssClass="form-control" placeholder="Enter your password" showPassword="true"/>
        <form:errors path="password" cssClass="field-error"/>
      </div>
      <div class="form-group">
        <label for="role">Role</label>
        <form:select path="role" id="role" cssClass="form-control">
          <form:option value="" label="-- Select Role --"/>
          <form:option value="User" label="User"/>
          <form:option value="Admin" label="Admin"/>
        </form:select>
        <form:errors path="role" cssClass="field-error"/>
      </div>
      <button type="submit" class="btn btn-primary btn-block">Sign Up</button>
    </form:form>

    <p class="mt-2" style="text-align:center;">
      Already have an account? <a href="${pageContext.request.contextPath}/login">Login here</a>
    </p>
  </div>
</div>

<%@ include file="fragments/footer.jsp" %>
</body>
</html>
