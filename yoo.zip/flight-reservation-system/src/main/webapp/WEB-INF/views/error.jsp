<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Error - Flight Reservation System</title>
  <%@ include file="fragments/headAssets.jsp" %>
</head>
<body>
<%@ include file="fragments/header.jsp" %>

<div class="page-wrap" style="max-width:480px;">
  <div class="card text-center">
    <div class="alert-icon">
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <path d="M12 3.5L22 20.5H2L12 3.5Z"/><line x1="12" y1="10" x2="12" y2="14.5"/><circle cx="12" cy="17.3" r="0.9" fill="currentColor" stroke="none"/>
      </svg>
    </div>
    <h2 class="page-title">
      <c:choose>
        <c:when test="${not empty errorTitle}">${errorTitle}</c:when>
        <c:otherwise>Something Went Wrong</c:otherwise>
      </c:choose>
    </h2>
    <p class="page-subtitle">
      <c:choose>
        <c:when test="${not empty errorMessage}">${errorMessage}</c:when>
        <c:otherwise>An unexpected error occurred. Please try again later.</c:otherwise>
      </c:choose>
    </p>
    <a href="${pageContext.request.contextPath}/" class="btn btn-primary">Back to Home</a>
  </div>
</div>

<%@ include file="fragments/footer.jsp" %>
</body>
</html>
