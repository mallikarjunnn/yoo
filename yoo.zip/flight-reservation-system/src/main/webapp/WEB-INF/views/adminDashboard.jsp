<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Dashboard - Flight Reservation System</title>
  <%@ include file="fragments/headAssets.jsp" %>
</head>
<body>
<%@ include file="fragments/header.jsp" %>

<div class="page-wrap">
  <h2 class="page-title">Admin dashboard</h2>
  <p class="page-subtitle">Signed in as ${sessionScope.loggedInUser.email}</p>

  <div class="tile-grid">
    <div class="tile">
      <div class="tile-icon">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
      </div>
      <h3>Add new flight</h3>
      <p>Create a new flight route and schedule.</p>
      <a href="${pageContext.request.contextPath}/admin/flights/add" class="btn btn-primary btn-block">Add flight</a>
    </div>
    <div class="tile">
      <div class="tile-icon">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="18" x2="14" y2="18"/></svg>
      </div>
      <h3>View flights</h3>
      <p>See upcoming and completed journeys with booking stats.</p>
      <a href="${pageContext.request.contextPath}/admin/flights/view" class="btn btn-success btn-block">View flights</a>
    </div>
  </div>
</div>

<%@ include file="fragments/footer.jsp" %>
</body>
</html>
