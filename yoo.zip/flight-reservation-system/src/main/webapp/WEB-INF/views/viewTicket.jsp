<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>My Tickets - Flight Reservation System</title>
  <%@ include file="fragments/headAssets.jsp" %>
</head>
<body>
<%@ include file="fragments/header.jsp" %>

<div class="page-wrap">
  <h2 class="page-title">My tickets</h2>
  <p class="page-subtitle">Booking #${booking.bookingId} &middot; ${booking.flightNumber}: ${booking.source} &rarr; ${booking.destination}</p>

  <div class="ticket-grid">
    <c:forEach var="t" items="${tickets}">
      <div class="boarding-pass">
        <div class="pass-main">
          <div class="pass-eyebrow">${t.passengerName}</div>
          <div class="pass-route-row">
            <div class="city-block">
              <div class="city-code">${fn:toUpperCase(fn:substring(booking.source, 0, 3))}</div>
              <div class="city-name">${booking.source}</div>
            </div>
            <span class="path-line"></span>
            <div class="city-block" style="text-align:right;">
              <div class="city-code">${fn:toUpperCase(fn:substring(booking.destination, 0, 3))}</div>
              <div class="city-name">${booking.destination}</div>
            </div>
          </div>
          <div class="pass-fields">
            <div>
              <div class="pass-field-label">Journey date</div>
              <div class="pass-field-value">${t.journeyDate}</div>
            </div>
            <div>
              <div class="pass-field-label">Age / Gender</div>
              <div class="pass-field-value">${t.age} &middot; ${t.gender}</div>
            </div>
            <div>
              <div class="pass-field-label">Booking</div>
              <div class="pass-field-value">#${t.bookingId}</div>
            </div>
          </div>
        </div>
        <div class="pass-stub">
          <div>
            <div class="pass-field-label">Seat</div>
            <div class="pass-field-value">${t.seatNo}</div>
          </div>
          <div>
            <div class="pass-field-label">PNR</div>
            <div class="pass-field-value">${t.pnrNo}</div>
          </div>
          <div>
            <c:choose>
              <c:when test="${t.status == 'BOOKED'}">
                <span class="badge badge-booked">BOOKED</span>
              </c:when>
              <c:otherwise>
                <span class="badge badge-cancelled">CANCELLED</span>
              </c:otherwise>
            </c:choose>
          </div>
          <c:if test="${t.status == 'BOOKED'}">
            <form method="post" action="${pageContext.request.contextPath}/user/bookings/${booking.bookingId}/tickets/${t.pnrNo}/cancel"
                  onsubmit="return confirm('Cancel this passenger\'s ticket? Just this seat will be released.');">
              <button type="submit" class="btn btn-outline btn-sm btn-block">Cancel this ticket</button>
            </form>
          </c:if>
        </div>
      </div>
    </c:forEach>
  </div>

  <div class="confirm-actions">
    <a href="${pageContext.request.contextPath}/user/bookings" class="btn btn-outline">Back to My Bookings</a>
    <c:if test="${booking.status == 'BOOKED'}">
      <form method="post" action="${pageContext.request.contextPath}/user/bookings/${booking.bookingId}/cancel"
            onsubmit="return confirm('Cancel the entire booking? All remaining passengers on it will be released.');">
        <button type="submit" class="btn btn-danger">Cancel entire booking</button>
      </form>
    </c:if>
  </div>
</div>

<%@ include file="fragments/footer.jsp" %>
</body>
</html>
