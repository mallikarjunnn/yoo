<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Flight Reservation System</title>
  <%@ include file="fragments/headAssets.jsp" %>
</head>
<body>
<%@ include file="fragments/header.jsp" %>

<div class="page-wrap">
  <div class="hero">
    <h1>Where are we flying today?</h1>
    <p class="lead">Search by city, compare schedules, and book in a few steps. No login needed to look, just to book.</p>
  </div>

  <div class="grid-2">
    <div class="search-panel">
      <c:if test="${not empty searchError}">
        <div class="alert alert-error">${searchError}</div>
      </c:if>

      <form action="${pageContext.request.contextPath}/flights/search" method="get">
        <div class="form-group">
          <label for="source">From</label>
          <input type="text" id="source" name="source" class="form-control"
                 placeholder="Enter departure city" value="${source}" required>
        </div>
        <div class="form-group">
          <label for="destination">To</label>
          <input type="text" id="destination" name="destination" class="form-control"
                 placeholder="Enter destination city" value="${destination}" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block">Search Flights</button>
      </form>
    </div>

    <div class="card">
      <h2 class="page-title">Your account</h2>
      <c:choose>
        <c:when test="${not empty sessionScope.loggedInUser}">
          <p class="page-subtitle">Signed in as ${sessionScope.loggedInUser.email}</p>
          <a href="${pageContext.request.contextPath}/dashboard" class="btn btn-secondary btn-block">Go to Dashboard</a>
        </c:when>
        <c:otherwise>
          <p class="page-subtitle">Log in to book flights and manage your trips.</p>
          <a href="${pageContext.request.contextPath}/login" class="btn btn-primary btn-block mb-2">Login</a>
          <a href="${pageContext.request.contextPath}/signup" class="btn btn-outline btn-block">Sign Up</a>
        </c:otherwise>
      </c:choose>
    </div>
  </div>

  <c:if test="${searched}">
    <div class="board mt-2">
      <div class="board-header">
        <h2>${source} &rarr; ${destination}</h2>
        <span class="board-meta"><c:out value="${results.size()}"/> flight(s) found</span>
      </div>

      <c:choose>
        <c:when test="${empty results}">
          <div class="empty-state" style="color:#B7BECB;">No flights on this route yet. Try a different city pair.</div>
        </c:when>
        <c:otherwise>
          <c:forEach var="flight" items="${results}">
            <div class="board-row">
              <div class="board-flight-no">${flight.flightNumber}</div>
              <div class="board-route">
                <span class="city">${flight.source}</span>
                <span class="path"></span>
                <span class="city">${flight.destination}</span>
              </div>
              <div class="board-time">Dep ${flight.departureTime} &middot; Arr ${flight.arrivalTime}</div>
              <div class="board-price">
                <fmt:formatNumber value="${flight.pricePerSeat}" type="currency" currencySymbol="$" maxFractionDigits="0"/>
              </div>
              <div>
                <a href="${pageContext.request.contextPath}/booking/new?flightId=${flight.flightId}" class="btn btn-primary btn-sm">Book</a>
              </div>
            </div>
          </c:forEach>
        </c:otherwise>
      </c:choose>
    </div>
  </c:if>
</div>

<%@ include file="fragments/footer.jsp" %>
</body>
</html>
