<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Add Passenger - Flight Reservation System</title>
  <%@ include file="fragments/headAssets.jsp" %>
</head>
<body>
<%@ include file="fragments/header.jsp" %>

<div class="page-wrap" style="max-width:480px;">
  <div class="card">
    <h2 class="page-title mt-0">Add Passenger ${pending.currentPassengerIndex}</h2>
    <p class="page-subtitle mt-0">Remaining passengers: ${pending.numPassengers - pending.currentPassengerIndex}</p>

    <form:form modelAttribute="ticket" method="post" action="${pageContext.request.contextPath}/booking/passenger">
      <div class="form-group">
        <label for="passengerName">Passenger Name *</label>
        <form:input path="passengerName" id="passengerName" cssClass="form-control" placeholder="Enter full name"/>
        <form:errors path="passengerName" cssClass="field-error"/>
      </div>
      <div class="form-group">
        <label for="age">Age *</label>
        <form:input path="age" id="age" type="number" cssClass="form-control" placeholder="0"/>
        <form:errors path="age" cssClass="field-error"/>
      </div>
      <div class="form-group">
        <label for="gender">Gender *</label>
        <form:select path="gender" id="gender" cssClass="form-control">
          <form:option value="" label="Select Gender"/>
          <form:option value="Male" label="Male"/>
          <form:option value="Female" label="Female"/>
          <form:option value="Other" label="Other"/>
        </form:select>
        <form:errors path="gender" cssClass="field-error"/>
      </div>

      <c:choose>
        <c:when test="${pending.currentPassengerIndex == pending.numPassengers}">
          <button type="submit" class="btn btn-secondary btn-block">Complete Booking</button>
        </c:when>
        <c:otherwise>
          <button type="submit" class="btn btn-secondary btn-block">Add Passenger &amp; Continue</button>
        </c:otherwise>
      </c:choose>
    </form:form>

    <div class="boarding-track">
      <div class="boarding-track-fill" id="boardingFill" style="width: <c:out value='${(pending.currentPassengerIndex - 1) * 100 / pending.numPassengers}'/>%;"></div>
      <span class="boarding-plane" style="left: <c:out value='${(pending.currentPassengerIndex - 1) * 100 / pending.numPassengers}'/>%;">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M2 16.5L22 12L2 7.5L2 11L14 12L2 13L2 16.5Z"/></svg>
      </span>
    </div>
    <div class="progress-label">Passenger ${pending.currentPassengerIndex} of ${pending.numPassengers}</div>
  </div>
</div>

<%@ include file="fragments/footer.jsp" %>
</body>
</html>
