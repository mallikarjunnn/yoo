<%@ page contentType="text/html;charset=UTF-8" language="java" isErrorPage="true" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Something Went Wrong - Flight Reservation System</title>
  <%@ include file="fragments/headAssets.jsp" %>
</head>
<body>
<%@ include file="fragments/header.jsp" %>

<div class="page-wrap" style="max-width:480px;">
  <div class="card text-center">
    <div class="alert-icon">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <path d="M12 3.5L22 20.5H2L12 3.5Z"/><line x1="12" y1="10" x2="12" y2="14.5"/><circle cx="12" cy="17.3" r="0.9" fill="currentColor" stroke="none"/>
      </svg>
    </div>
    <h2 class="page-title">Something went wrong</h2>
    <p class="page-subtitle">An unexpected error occurred on our end. Nothing you did caused this. Please try again in a moment.</p>
    <a href="${pageContext.request.contextPath}/" class="btn btn-primary">Back to Home</a>
  </div>
</div>

<%@ include file="fragments/footer.jsp" %>
</body>
</html>
