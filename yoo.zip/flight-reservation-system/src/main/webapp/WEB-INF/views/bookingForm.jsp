<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Book Flight - Flight Reservation System</title>
  <%@ include file="fragments/headAssets.jsp" %>
</head>
<body>
<%@ include file="fragments/header.jsp" %>

<div class="page-wrap" style="max-width:480px;">
  <div class="card">
    <h2 class="page-title">Book flight</h2>
    <p class="page-subtitle mt-0">Pick a journey date and how many are travelling.</p>

    <div class="alert alert-info mono" style="font-size:13px;">
      ${flight.flightNumber} &nbsp;&middot;&nbsp; ${flight.source} &rarr; ${flight.destination}
      &nbsp;&middot;&nbsp; Dep ${flight.departureTime} / Arr ${flight.arrivalTime}
    </div>

    <c:if test="${not empty formError}">
      <div class="alert alert-error">${formError}</div>
    </c:if>

    <form method="post" action="${pageContext.request.contextPath}/booking/new">
      <input type="hidden" name="flightId" value="${flight.flightId}">
      <div class="form-group">
        <label for="journeyDate">Journey date</label>
        <input type="date" id="journeyDate" name="journeyDate" class="form-control"
               value="${journeyDate}" required>
      </div>
      <div class="form-group">
        <label for="numPassengers">Number of passengers</label>
        <input type="number" id="numPassengers" name="numPassengers" class="form-control"
               min="1" max="10" value="${numPassengers}" required>
        <div class="form-hint">Up to 10 passengers per booking</div>
      </div>
      <button type="submit" class="btn btn-primary btn-block mb-2">Continue to passenger details</button>
      <a href="${pageContext.request.contextPath}/dashboard" class="btn btn-outline btn-block">Back to Dashboard</a>
    </form>
  </div>
</div>

<%@ include file="fragments/footer.jsp" %>
</body>
</html>
