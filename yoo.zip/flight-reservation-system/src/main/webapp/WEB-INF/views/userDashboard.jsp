<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>My Dashboard - Flight Reservation System</title>
  <%@ include file="fragments/headAssets.jsp" %>
</head>
<body>
<%@ include file="fragments/header.jsp" %>

<div class="page-wrap">
  <h2 class="page-title">My dashboard</h2>
  <p class="page-subtitle">Signed in as ${sessionScope.loggedInUser.email}</p>

  <div class="tile-grid">
    <div class="tile">
      <div class="tile-icon">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="18" x2="14" y2="18"/></svg>
      </div>
      <h3>My bookings</h3>
      <p>View, track, and cancel your flight bookings.</p>
      <a href="${pageContext.request.contextPath}/user/bookings" class="btn btn-secondary btn-block">View my bookings</a>
    </div>
    <div class="tile">
      <div class="tile-icon">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><line x1="20" y1="20" x2="15.8" y2="15.8"/></svg>
      </div>
      <h3>Search flights</h3>
      <p>Find and book a new flight.</p>
      <a href="${pageContext.request.contextPath}/" class="btn btn-success btn-block">Find flights</a>
    </div>
  </div>
</div>

<%@ include file="fragments/footer.jsp" %>
</body>
</html>
