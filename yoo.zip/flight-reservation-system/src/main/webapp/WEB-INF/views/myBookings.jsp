<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>My Bookings - Flight Reservation System</title>
  <%@ include file="fragments/headAssets.jsp" %>
</head>
<body>
<%@ include file="fragments/header.jsp" %>

<div class="page-wrap">
  <h2 class="page-title">My bookings</h2>
  <p class="page-subtitle">Need to drop just one or two passengers from a multi-seat booking? Open View Tickets and cancel that seat there. Cancel all releases the whole booking.</p>

  <div class="card">
    <c:choose>
      <c:when test="${empty bookings}">
        <div class="empty-state">You haven't made any bookings yet. <a href="${pageContext.request.contextPath}/">Search flights</a> to get started.</div>
      </c:when>
      <c:otherwise>
        <div class="table-scroll">
          <table class="data-table">
            <thead>
              <tr>
                <th>Booking ID</th><th>Flight Number</th><th>Journey Date</th>
                <th>Seats</th><th>Total Price</th><th>Status</th><th>Action</th><th>Cancel All</th>
              </tr>
            </thead>
            <tbody>
              <c:forEach var="b" items="${bookings}">
                <tr>
                  <td>${b.bookingId}</td>
                  <td>${b.flightNumber}</td>
                  <td>${b.journeyDate}</td>
                  <td>
                    <c:choose>
                      <c:when test="${b.activeSeats < b.seats}">${b.activeSeats} of ${b.seats}</c:when>
                      <c:otherwise>${b.seats}</c:otherwise>
                    </c:choose>
                  </td>
                  <td><fmt:formatNumber value="${b.totalPrice}" type="currency" currencySymbol="$" maxFractionDigits="0"/></td>
                  <td>
                    <c:choose>
                      <c:when test="${b.status == 'BOOKED'}">
                        <span class="badge badge-booked">BOOKED</span>
                      </c:when>
                      <c:otherwise>
                        <span class="badge badge-cancelled">CANCELLED</span>
                      </c:otherwise>
                    </c:choose>
                  </td>
                  <td>
                    <a href="${pageContext.request.contextPath}/user/bookings/${b.bookingId}/tickets" class="btn btn-outline btn-sm">View Tickets</a>
                  </td>
                  <td>
                    <c:choose>
                      <c:when test="${b.status == 'BOOKED'}">
                        <form method="post" action="${pageContext.request.contextPath}/user/bookings/${b.bookingId}/cancel"
                              onsubmit="return confirm('Cancel the entire booking? All seats on it will be released.');">
                          <button type="submit" class="btn btn-danger btn-sm">Cancel all</button>
                        </form>
                      </c:when>
                      <c:otherwise>
                        <button type="button" class="btn btn-outline btn-sm" disabled>Cancel all</button>
                      </c:otherwise>
                    </c:choose>
                  </td>
                </tr>
              </c:forEach>
            </tbody>
          </table>
        </div>
      </c:otherwise>
    </c:choose>
  </div>
</div>

<%@ include file="fragments/footer.jsp" %>
</body>
</html>
