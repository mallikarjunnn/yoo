<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login - Flight Reservation System</title>
  <%@ include file="fragments/headAssets.jsp" %>
</head>
<body>
<%@ include file="fragments/header.jsp" %>

<div class="page-wrap" style="max-width:420px;">
  <div class="card">
    <h2 class="page-title">Login</h2>
    <p class="page-subtitle">Access your account to book and manage flights.</p>

    <c:if test="${not empty signupSuccess}">
      <div class="alert alert-success">${signupSuccess}</div>
    </c:if>
    <c:if test="${not empty loginError}">
      <div class="alert alert-error">${loginError}</div>
    </c:if>

    <form method="post" action="${pageContext.request.contextPath}/login">
      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" class="form-control"
               placeholder="Enter your email" value="<c:out value='${loginEmail}'/>" required>
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" class="form-control"
               placeholder="Enter your password" required>
      </div>
      <button type="submit" class="btn btn-primary btn-block">Login</button>
    </form>

    <p class="mt-2" style="text-align:center;">
      Don't have an account? <a href="${pageContext.request.contextPath}/signup">Sign up here</a>
    </p>
  </div>
</div>

<%@ include file="fragments/footer.jsp" %>
</body>
</html>
