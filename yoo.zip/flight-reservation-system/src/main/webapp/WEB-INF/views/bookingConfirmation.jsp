<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Booking Confirmed - Flight Reservation System</title>
  <%@ include file="fragments/headAssets.jsp" %>
</head>
<body>
<%@ include file="fragments/header.jsp" %>

<div class="page-wrap" style="max-width:640px;">
  <div class="confirm-banner">
    <span class="check">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="4 12.5 9.5 18 20 6"/></svg>
    </span>
    <h2>You're booked</h2>
    <p>Booking #${booking.bookingId} &middot; ${booking.flightNumber} on ${booking.journeyDate}</p>
  </div>

  <div class="ticket-grid" style="grid-template-columns: 1fr;">
    <c:forEach var="t" items="${tickets}">
      <div class="boarding-pass">
        <div class="pass-main">
          <div class="pass-eyebrow">Boarding pass &middot; ${t.passengerName}</div>
          <div class="pass-route-row">
            <div class="city-block">
              <div class="city-code">${fn:toUpperCase(fn:substring(booking.source, 0, 3))}</div>
              <div class="city-name">${booking.source}</div>
            </div>
            <span class="path-line"></span>
            <div class="city-block" style="text-align:right;">
              <div class="city-code">${fn:toUpperCase(fn:substring(booking.destination, 0, 3))}</div>
              <div class="city-name">${booking.destination}</div>
            </div>
          </div>
          <div class="pass-fields">
            <div>
              <div class="pass-field-label">Flight</div>
              <div class="pass-field-value">${booking.flightNumber}</div>
            </div>
            <div>
              <div class="pass-field-label">Journey date</div>
              <div class="pass-field-value">${t.journeyDate}</div>
            </div>
            <div>
              <div class="pass-field-label">Age / Gender</div>
              <div class="pass-field-value">${t.age} &middot; ${t.gender}</div>
            </div>
          </div>
        </div>
        <div class="pass-stub">
          <div>
            <div class="pass-field-label">Seat</div>
            <div class="pass-field-value">${t.seatNo}</div>
          </div>
          <div>
            <div class="pass-field-label">PNR</div>
            <div class="pass-field-value">${t.pnrNo}</div>
          </div>
          <div>
            <span class="badge badge-booked">${t.status}</span>
          </div>
        </div>
      </div>
    </c:forEach>
  </div>

  <div class="next-steps">
    <h4>Before you fly</h4>
    <ul>
      <li>Save your booking ID for future reference</li>
      <li>Review or cancel this booking anytime from My Bookings</li>
      <li>Arrive at the airport at least 2 hours before departure</li>
      <li>Online check-in opens 24 hours before the flight</li>
    </ul>
  </div>

  <div class="confirm-actions">
    <a href="${pageContext.request.contextPath}/dashboard" class="btn btn-success">Go to Dashboard</a>
    <a href="${pageContext.request.contextPath}/user/bookings/${booking.bookingId}/tickets" class="btn btn-outline">View in My Tickets</a>
  </div>
</div>

<%@ include file="fragments/footer.jsp" %>
</body>
</html>
