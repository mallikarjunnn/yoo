<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Add Flight - Flight Reservation System</title>
  <%@ include file="fragments/headAssets.jsp" %>
</head>
<body>
<%@ include file="fragments/header.jsp" %>

<div class="page-wrap" style="max-width:560px;">
  <div class="card">
    <h2 class="page-title">Add Flight</h2>
    <p class="page-subtitle">All flights run daily. Default capacity is 20 seats.</p>

    <c:if test="${not empty flightAdded}">
      <div class="alert alert-success">${flightAdded}</div>
    </c:if>

    <form:form modelAttribute="flight" method="post" action="${pageContext.request.contextPath}/admin/flights/add">
      <div class="grid-2">
        <div class="form-group">
          <label for="flightNumber">Flight Number</label>
          <form:input path="flightNumber" id="flightNumber" cssClass="form-control" placeholder="Enter flight number"/>
          <form:errors path="flightNumber" cssClass="field-error"/>
        </div>
        <div class="form-group">
          <label for="capacity">Capacity</label>
          <form:input path="capacity" id="capacity" type="number" cssClass="form-control" placeholder="20"/>
          <form:errors path="capacity" cssClass="field-error"/>
        </div>
        <div class="form-group">
          <label for="source">Source</label>
          <form:input path="source" id="source" cssClass="form-control" placeholder="Enter source city"/>
          <form:errors path="source" cssClass="field-error"/>
        </div>
        <div class="form-group">
          <label for="destination">Destination</label>
          <form:input path="destination" id="destination" cssClass="form-control" placeholder="Enter destination city"/>
          <form:errors path="destination" cssClass="field-error"/>
        </div>
        <div class="form-group">
          <label for="departureTime">Departure Time</label>
          <form:input path="departureTime" id="departureTime" type="time" cssClass="form-control"/>
          <form:errors path="departureTime" cssClass="field-error"/>
        </div>
        <div class="form-group">
          <label for="arrivalTime">Arrival Time</label>
          <form:input path="arrivalTime" id="arrivalTime" type="time" cssClass="form-control"/>
          <form:errors path="arrivalTime" cssClass="field-error"/>
        </div>
      </div>
      <div class="form-group">
        <label for="pricePerSeat">Price per Seat ($)</label>
        <form:input path="pricePerSeat" id="pricePerSeat" type="number" cssClass="form-control" placeholder="0.0"/>
        <form:errors path="pricePerSeat" cssClass="field-error"/>
      </div>
      <button type="submit" class="btn btn-success btn-block">Add Flight</button>
    </form:form>
  </div>
</div>

<%@ include file="fragments/footer.jsp" %>
</body>
</html>
