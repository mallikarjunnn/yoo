<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Page Not Found - Flight Reservation System</title>
  <%@ include file="fragments/headAssets.jsp" %>
</head>
<body>
<%@ include file="fragments/header.jsp" %>

<div class="page-wrap" style="max-width:480px;">
  <div class="card text-center">
    <div class="alert-icon">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true">
        <circle cx="11" cy="11" r="6.5"/><line x1="20" y1="20" x2="15.8" y2="15.8"/>
      </svg>
    </div>
    <h2 class="page-title">Page not found</h2>
    <p class="page-subtitle">The page you're looking for doesn't exist or may have moved.</p>
    <a href="${pageContext.request.contextPath}/" class="btn btn-primary">Back to Home</a>
  </div>
</div>

<%@ include file="fragments/footer.jsp" %>
</body>
</html>
