<nav class="navbar">
  <div class="navbar-inner">
    <a href="${pageContext.request.contextPath}/" class="brand">
      <svg class="brand-mark" width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
        <path d="M2 16.5L22 12L2 7.5L2 11L14 12L2 13L2 16.5Z" fill="currentColor"/>
      </svg>
      Flight Reservation
    </a>
    <div class="nav-links">
      <a href="${pageContext.request.contextPath}/">Home</a>
      <c:choose>
        <c:when test="${not empty sessionScope.loggedInUser}">
          <c:if test="${sessionScope.loggedInUser.role == 'Admin'}">
            <a href="${pageContext.request.contextPath}/admin/dashboard">Dashboard</a>
            <a href="${pageContext.request.contextPath}/admin/flights/add">Add Flight</a>
            <a href="${pageContext.request.contextPath}/admin/flights/view">View Flights</a>
          </c:if>
          <c:if test="${sessionScope.loggedInUser.role != 'Admin'}">
            <a href="${pageContext.request.contextPath}/user/dashboard">Dashboard</a>
            <a href="${pageContext.request.contextPath}/user/bookings">My Bookings</a>
          </c:if>
          <span class="role-badge">${sessionScope.loggedInUser.role}</span>
          <a href="${pageContext.request.contextPath}/logout" class="nav-btn-outline">Logout</a>
        </c:when>
        <c:otherwise>
          <a href="${pageContext.request.contextPath}/login" class="nav-btn-outline">Login</a>
          <a href="${pageContext.request.contextPath}/signup" class="nav-btn-primary">Sign Up</a>
        </c:otherwise>
      </c:choose>

      <button type="button" class="theme-switch" id="themeSwitch" onclick="toggleTheme()" aria-label="Switch between dark and light mode" title="Switch theme">
        <span class="switch-icons">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#C6CBD6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z"/>
          </svg>
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#C6CBD6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <circle cx="12" cy="12" r="4"/>
            <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>
          </svg>
        </span>
        <span class="switch-thumb"></span>
      </button>
    </div>
  </div>
</nav>
