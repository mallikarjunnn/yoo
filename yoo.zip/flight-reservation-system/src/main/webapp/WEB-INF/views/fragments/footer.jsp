<footer class="site-footer">
  <div class="site-footer-inner">
    Flight Reservation System, a Spring MVC training project.
  </div>
</footer>
<script src="${pageContext.request.contextPath}/resources/js/script.js"></script>
