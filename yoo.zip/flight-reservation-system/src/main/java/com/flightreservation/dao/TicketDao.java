package com.flightreservation.dao;

import com.flightreservation.model.Ticket;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;

@Repository
public class TicketDao {

    private final JdbcTemplate jdbcTemplate;

    public TicketDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<Ticket> ROW_MAPPER = (rs, rowNum) -> {
        Ticket t = new Ticket();
        t.setPnrNo(rs.getLong("pnr_no"));
        t.setPassengerName(rs.getString("passenger_name"));
        t.setGender(rs.getString("gender"));
        t.setAge(rs.getInt("age"));
        t.setJourneyDate(rs.getDate("journey_date").toLocalDate());
        t.setSeatNo(rs.getString("seat_no"));
        t.setBookingId(rs.getLong("booking_id"));
        t.setStatus(rs.getString("status"));
        return t;
    };

    public Long save(Ticket ticket) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO ticket (passenger_name, gender, age, journey_date, seat_no, booking_id, status) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, ticket.getPassengerName());
            ps.setString(2, ticket.getGender());
            ps.setInt(3, ticket.getAge());
            ps.setDate(4, Date.valueOf(ticket.getJourneyDate()));
            ps.setString(5, ticket.getSeatNo());
            ps.setLong(6, ticket.getBookingId());
            ps.setString(7, ticket.getStatus());
            return ps;
        }, keyHolder);
        return keyHolder.getKey().longValue();
    }

    public List<Ticket> findByBookingId(Long bookingId) {
        return jdbcTemplate.query(
                "SELECT * FROM ticket WHERE booking_id = ? ORDER BY pnr_no", ROW_MAPPER, bookingId);
    }

    public java.util.Optional<Ticket> findByPnrAndBookingId(Long pnrNo, Long bookingId) {
        try {
            Ticket t = jdbcTemplate.queryForObject(
                    "SELECT * FROM ticket WHERE pnr_no = ? AND booking_id = ?", ROW_MAPPER, pnrNo, bookingId);
            return java.util.Optional.ofNullable(t);
        } catch (org.springframework.dao.EmptyResultDataAccessException e) {
            return java.util.Optional.empty();
        }
    }

    public void updateStatusByBookingId(Long bookingId, String status) {
        jdbcTemplate.update("UPDATE ticket SET status = ? WHERE booking_id = ?", status, bookingId);
    }

    /**
     * Cancels a single passenger's ticket, independent of the rest of the booking.
     */
    public void updateStatusByPnr(Long pnrNo, String status) {
        jdbcTemplate.update("UPDATE ticket SET status = ? WHERE pnr_no = ?", status, pnrNo);
    }

    /**
     * Non-cancelled ticket count remaining on a booking, used to decide whether the
     * parent booking should flip to CANCELLED once its last active ticket is cancelled.
     */
    public int countActiveTickets(Long bookingId) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM ticket WHERE booking_id = ? AND status <> 'CANCELLED'",
                Integer.class, bookingId);
        return count == null ? 0 : count;
    }

    /**
     * Highest seat-number suffix already used on this flight/journey date,
     * so new bookings continue the sequence (A1, A2, A3 ...). Cancelled tickets
     * don't hold a seat, so they're excluded here too.
     */
    public int countSeatsTakenForFlightOnDate(Long flightId, java.time.LocalDate journeyDate) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM ticket t JOIN booking b ON t.booking_id = b.booking_id " +
                        "WHERE b.flight_id = ? AND b.journey_date = ? AND t.status <> 'CANCELLED'",
                Integer.class, flightId, journeyDate);
        return count == null ? 0 : count;
    }
}
