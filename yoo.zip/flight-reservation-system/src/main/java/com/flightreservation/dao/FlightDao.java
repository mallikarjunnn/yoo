package com.flightreservation.dao;

import com.flightreservation.model.Flight;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

@Repository
public class FlightDao {

    private final JdbcTemplate jdbcTemplate;

    public FlightDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<Flight> ROW_MAPPER = (rs, rowNum) -> {
        Flight f = new Flight();
        f.setFlightId(rs.getLong("flight_id"));
        f.setFlightNumber(rs.getString("flight_number"));
        f.setSource(rs.getString("source"));
        f.setDestination(rs.getString("destination"));
        f.setDepartureTime(rs.getString("departure_time"));
        f.setArrivalTime(rs.getString("arrival_time"));
        f.setCapacity(rs.getInt("capacity"));
        f.setPricePerSeat(rs.getDouble("price_per_seat"));
        return f;
    };

    public boolean existsByFlightNumber(String flightNumber) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM flight WHERE flight_number = ?", Integer.class, flightNumber);
        return count != null && count > 0;
    }

    public Long save(Flight flight) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO flight (flight_number, source, destination, departure_time, arrival_time, capacity, price_per_seat) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, flight.getFlightNumber());
            ps.setString(2, flight.getSource());
            ps.setString(3, flight.getDestination());
            ps.setString(4, flight.getDepartureTime());
            ps.setString(5, flight.getArrivalTime());
            ps.setInt(6, flight.getCapacity());
            ps.setDouble(7, flight.getPricePerSeat());
            return ps;
        }, keyHolder);
        return keyHolder.getKey().longValue();
    }

    public List<Flight> searchByRoute(String source, String destination) {
        return jdbcTemplate.query(
                "SELECT * FROM flight WHERE LOWER(source) = LOWER(?) AND LOWER(destination) = LOWER(?) ORDER BY departure_time",
                ROW_MAPPER, source, destination);
    }

    public List<Flight> findAll() {
        return jdbcTemplate.query("SELECT * FROM flight ORDER BY flight_number", ROW_MAPPER);
    }

    public Optional<Flight> findById(Long flightId) {
        try {
            Flight f = jdbcTemplate.queryForObject(
                    "SELECT * FROM flight WHERE flight_id = ?", ROW_MAPPER, flightId);
            return Optional.ofNullable(f);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    /**
     * Seats currently held (non-cancelled) for a given flight on a given journey date.
     * Counted per-ticket (not per-booking) so cancelling individual passengers on a
     * multi-passenger booking correctly frees up just their seats.
     */
    public int getBookedSeats(Long flightId, java.time.LocalDate journeyDate) {
        Integer booked = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM ticket t JOIN booking b ON t.booking_id = b.booking_id " +
                        "WHERE b.flight_id = ? AND b.journey_date = ? AND t.status <> 'CANCELLED'",
                Integer.class, flightId, journeyDate);
        return booked == null ? 0 : booked;
    }
}
