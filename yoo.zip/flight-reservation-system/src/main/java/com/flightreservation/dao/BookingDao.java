package com.flightreservation.dao;

import com.flightreservation.model.Booking;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public class BookingDao {

    private final JdbcTemplate jdbcTemplate;

    public BookingDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<Booking> ROW_MAPPER = (rs, rowNum) -> {
        Booking b = new Booking();
        b.setBookingId(rs.getLong("booking_id"));
        b.setBookingDate(rs.getDate("booking_date").toLocalDate());
        b.setJourneyDate(rs.getDate("journey_date").toLocalDate());
        b.setSeats(rs.getInt("seats"));
        b.setTotalPrice(rs.getDouble("total_price"));
        b.setStatus(rs.getString("status"));
        b.setFlightId(rs.getLong("flight_id"));
        b.setUserId(rs.getLong("user_id"));
        return b;
    };

    // Row mapper for queries joined with flight, for display purposes
    private static final RowMapper<Booking> JOINED_ROW_MAPPER = (rs, rowNum) -> {
        Booking b = ROW_MAPPER.mapRow(rs, rowNum);
        b.setFlightNumber(rs.getString("flight_number"));
        b.setSource(rs.getString("source"));
        b.setDestination(rs.getString("destination"));
        return b;
    };

    // Same as above, plus a live count of non-cancelled tickets (reflects partial cancellations)
    private static final RowMapper<Booking> JOINED_WITH_ACTIVE_SEATS_ROW_MAPPER = (rs, rowNum) -> {
        Booking b = JOINED_ROW_MAPPER.mapRow(rs, rowNum);
        b.setActiveSeats(rs.getInt("active_seats"));
        return b;
    };

    public Long save(Booking booking) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO booking (booking_date, journey_date, seats, total_price, status, flight_id, user_id) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setDate(1, Date.valueOf(booking.getBookingDate()));
            ps.setDate(2, Date.valueOf(booking.getJourneyDate()));
            ps.setInt(3, booking.getSeats());
            ps.setDouble(4, booking.getTotalPrice());
            ps.setString(5, booking.getStatus());
            ps.setLong(6, booking.getFlightId());
            ps.setLong(7, booking.getUserId());
            return ps;
        }, keyHolder);
        return keyHolder.getKey().longValue();
    }

    public Optional<Booking> findById(Long bookingId) {
        try {
            Booking b = jdbcTemplate.queryForObject(
                    "SELECT b.*, f.flight_number, f.source, f.destination FROM booking b " +
                            "JOIN flight f ON b.flight_id = f.flight_id WHERE b.booking_id = ?",
                    JOINED_ROW_MAPPER, bookingId);
            return Optional.ofNullable(b);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    public List<Booking> findByUserId(Long userId) {
        return jdbcTemplate.query(
                "SELECT b.*, f.flight_number, f.source, f.destination, " +
                        "(SELECT COUNT(*) FROM ticket t WHERE t.booking_id = b.booking_id AND t.status <> 'CANCELLED') AS active_seats " +
                        "FROM booking b JOIN flight f ON b.flight_id = f.flight_id " +
                        "WHERE b.user_id = ? ORDER BY b.booking_id DESC",
                JOINED_WITH_ACTIVE_SEATS_ROW_MAPPER, userId);
    }

    public void updateStatus(Long bookingId, String status) {
        jdbcTemplate.update("UPDATE booking SET status = ? WHERE booking_id = ?", status, bookingId);
    }

    /**
     * Admin "View Flights" summary: only flight + journey_date combinations
     * that have at least one booking, with aggregate stats.
     */
    public List<Map<String, Object>> getJourneySummary(boolean upcoming) {
        String comparison = upcoming ? ">=" : "<";
        String sql = "SELECT f.flight_number AS flightNumber, b.journey_date AS journeyDate, " +
                "SUM(b.seats) AS totalPassengers, COUNT(b.booking_id) AS totalBookings, " +
                "SUM(b.total_price) AS totalRevenue, DATEDIFF(b.journey_date, CURDATE()) AS daysUntilJourney " +
                "FROM booking b JOIN flight f ON b.flight_id = f.flight_id " +
                "WHERE b.status <> 'CANCELLED' AND b.journey_date " + comparison + " CURDATE() " +
                "GROUP BY f.flight_number, b.journey_date " +
                "ORDER BY b.journey_date " + (upcoming ? "ASC" : "DESC");
        return jdbcTemplate.queryForList(sql);
    }
}
