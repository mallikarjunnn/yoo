package com.flightreservation.model;

import java.time.LocalDate;

public class Booking {

    private Long bookingId;
    private LocalDate bookingDate;
    private LocalDate journeyDate;
    private Integer seats;
    private Double totalPrice;
    private String status; // BOOKED / CANCELLED
    private Long flightId;
    private Long userId;

    // Display-only fields populated via join queries (not persisted directly here)
    private String flightNumber;
    private String source;
    private String destination;
    private Integer activeSeats;

    public Booking() {}

    public Long getBookingId() { return bookingId; }
    public void setBookingId(Long bookingId) { this.bookingId = bookingId; }

    public LocalDate getBookingDate() { return bookingDate; }
    public void setBookingDate(LocalDate bookingDate) { this.bookingDate = bookingDate; }

    public LocalDate getJourneyDate() { return journeyDate; }
    public void setJourneyDate(LocalDate journeyDate) { this.journeyDate = journeyDate; }

    public Integer getSeats() { return seats; }
    public void setSeats(Integer seats) { this.seats = seats; }

    public Double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(Double totalPrice) { this.totalPrice = totalPrice; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Long getFlightId() { return flightId; }
    public void setFlightId(Long flightId) { this.flightId = flightId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getFlightNumber() { return flightNumber; }
    public void setFlightNumber(String flightNumber) { this.flightNumber = flightNumber; }

    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }

    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }

    public Integer getActiveSeats() { return activeSeats; }
    public void setActiveSeats(Integer activeSeats) { this.activeSeats = activeSeats; }
}
