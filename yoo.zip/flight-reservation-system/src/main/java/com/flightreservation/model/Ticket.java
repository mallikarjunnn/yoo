package com.flightreservation.model;

import java.time.LocalDate;
import javax.validation.constraints.*;

public class Ticket implements java.io.Serializable {

    private Long pnrNo;

    @NotBlank(message = "Passenger name is required")
    @Size(max = 50)
    private String passengerName;

    @NotBlank(message = "Gender is required")
    private String gender;

    @NotNull(message = "Age is required")
    @Min(value = 1, message = "Age must be at least 1")
    @Max(value = 120, message = "Enter a valid age")
    private Integer age;

    private LocalDate journeyDate;
    private String seatNo;
    private Long bookingId;
    private String status; // BOOKED / CANCELLED

    // Display-only, populated via join for "My Tickets"
    private Long flightBookingId;

    public Ticket() {}

    public Long getPnrNo() { return pnrNo; }
    public void setPnrNo(Long pnrNo) { this.pnrNo = pnrNo; }

    public String getPassengerName() { return passengerName; }
    public void setPassengerName(String passengerName) { this.passengerName = passengerName; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public Integer getAge() { return age; }
    public void setAge(Integer age) { this.age = age; }

    public LocalDate getJourneyDate() { return journeyDate; }
    public void setJourneyDate(LocalDate journeyDate) { this.journeyDate = journeyDate; }

    public String getSeatNo() { return seatNo; }
    public void setSeatNo(String seatNo) { this.seatNo = seatNo; }

    public Long getBookingId() { return bookingId; }
    public void setBookingId(Long bookingId) { this.bookingId = bookingId; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Long getFlightBookingId() { return flightBookingId; }
    public void setFlightBookingId(Long flightBookingId) { this.flightBookingId = flightBookingId; }
}
