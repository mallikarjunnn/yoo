package com.flightreservation.exception;

public class DuplicateFlightNumberException extends RuntimeException {
    public DuplicateFlightNumberException(String message) {
        super(message);
    }
}
