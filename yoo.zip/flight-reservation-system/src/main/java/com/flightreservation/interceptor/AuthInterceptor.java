package com.flightreservation.interceptor;

import com.flightreservation.model.User;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Minimal, manual session-based access control (no Spring Security, per Rules.md).
 * Gates /booking/**, /user/** and /admin/** behind a logged-in session, and
 * additionally requires the "Admin" role for /admin/**.
 */
@Component
public class AuthInterceptor implements HandlerInterceptor {

    public static final String SESSION_USER = "loggedInUser";
    public static final String REDIRECT_AFTER_LOGIN = "redirectAfterLogin";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        HttpSession session = request.getSession();
        Object userObj = session.getAttribute(SESSION_USER);

        if (!(userObj instanceof User)) {
            String target = request.getRequestURI();
            if (request.getQueryString() != null) {
                target += "?" + request.getQueryString();
            }
            session.setAttribute(REDIRECT_AFTER_LOGIN, target);
            response.sendRedirect(request.getContextPath() + "/login");
            return false;
        }

        User user = (User) userObj;
        String uri = request.getRequestURI();
        if (uri.contains("/admin/") && !"Admin".equalsIgnoreCase(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return false;
        }
        if (uri.contains("/user/") && !"User".equalsIgnoreCase(user.getRole())) {
            response.sendRedirect(request.getContextPath() + "/dashboard");
            return false;
        }

        return true;
    }
}
