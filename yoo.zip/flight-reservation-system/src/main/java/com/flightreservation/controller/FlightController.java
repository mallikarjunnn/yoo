package com.flightreservation.controller;

import com.flightreservation.model.Flight;
import com.flightreservation.service.FlightService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * Handles flight search (no login required, per PRD 4.2 Home Page).
 * Results render on the home view, matching the Search Flight wireframe.
 */
@Controller
public class FlightController {

    private final FlightService flightService;

    public FlightController(FlightService flightService) {
        this.flightService = flightService;
    }

    @GetMapping("/flights/search")
    public String search(@RequestParam String source,
                          @RequestParam String destination,
                          Model model) {
        model.addAttribute("source", source);
        model.addAttribute("destination", destination);
        model.addAttribute("searched", true);

        if (source == null || source.trim().isEmpty() || destination == null || destination.trim().isEmpty()) {
            model.addAttribute("searchError", "Please enter both a departure and destination city.");
            return "home";
        }

        List<Flight> results = flightService.searchFlights(source, destination);
        model.addAttribute("results", results);
        return "home";
    }
}
