package com.flightreservation.controller;

import com.flightreservation.exception.DuplicateEmailException;
import com.flightreservation.exception.InvalidCredentialsException;
import com.flightreservation.interceptor.AuthInterceptor;
import com.flightreservation.model.User;
import com.flightreservation.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@Controller
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/signup")
    public String signupForm(Model model) {
        if (!model.containsAttribute("user")) {
            model.addAttribute("user", new User());
        }
        return "signup";
    }

    @PostMapping("/signup")
    public String signup(@Valid @ModelAttribute("user") User user,
                          org.springframework.validation.BindingResult bindingResult,
                          RedirectAttributes redirectAttributes,
                          Model model) {
        if (bindingResult.hasErrors()) {
            return "signup";
        }
        try {
            userService.signUp(user);
        } catch (DuplicateEmailException e) {
            bindingResult.rejectValue("email", "duplicate", e.getMessage());
            return "signup";
        }
        redirectAttributes.addFlashAttribute("signupSuccess", "Account created! Please log in.");
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String loginForm(Model model) {
        if (!model.containsAttribute("loginEmail")) {
            model.addAttribute("loginEmail", "");
        }
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String email,
                         @RequestParam String password,
                         HttpServletRequest request,
                         Model model) {
        try {
            User user = userService.login(email, password);
            HttpSession session = request.getSession();
            session.setAttribute(AuthInterceptor.SESSION_USER, user);

            Object redirectTarget = session.getAttribute(AuthInterceptor.REDIRECT_AFTER_LOGIN);
            session.removeAttribute(AuthInterceptor.REDIRECT_AFTER_LOGIN);
            if (redirectTarget != null) {
                return "redirect:" + redirectTarget;
            }
            return "redirect:/dashboard";
        } catch (InvalidCredentialsException e) {
            model.addAttribute("loginEmail", email);
            model.addAttribute("loginError", e.getMessage());
            return "login";
        } catch (RuntimeException e) {
            // Defensive fallback: whatever went wrong, never let it bubble past this
            // point as a raw, unhandled exception. Show the same friendly message
            // a wrong password would show rather than exposing internals.
            model.addAttribute("loginEmail", email);
            model.addAttribute("loginError", "We couldn't log you in. Please check your details and try again.");
            return "login";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        return "redirect:/";
    }

    /**
     * Single dashboard entry point: routes to the admin or user dashboard
     * view based on the logged-in user's role.
     */
    @GetMapping("/dashboard")
    public String dashboard(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        User user = session == null ? null : (User) session.getAttribute(AuthInterceptor.SESSION_USER);
        if (user == null) {
            return "redirect:/login";
        }
        if ("Admin".equalsIgnoreCase(user.getRole())) {
            return "redirect:/admin/dashboard";
        }
        return "redirect:/user/dashboard";
    }
}
