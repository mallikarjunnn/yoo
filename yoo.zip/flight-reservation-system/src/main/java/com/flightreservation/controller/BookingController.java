package com.flightreservation.controller;

import com.flightreservation.exception.ResourceNotFoundException;
import com.flightreservation.interceptor.AuthInterceptor;
import com.flightreservation.model.Booking;
import com.flightreservation.model.Flight;
import com.flightreservation.model.Ticket;
import com.flightreservation.model.User;
import com.flightreservation.service.BookingService;
import com.flightreservation.service.FlightService;
import com.flightreservation.service.TicketService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

/**
 * Handles the full Book Flight journey: Booking Form -> Add Passenger (looped) -> Confirmation.
 * All endpoints here require login (enforced by AuthInterceptor on /booking/**).
 */
@Controller
@RequestMapping("/booking")
public class BookingController {

    private static final String PENDING_BOOKING = "pendingBooking";

    private final FlightService flightService;
    private final BookingService bookingService;
    private final TicketService ticketService;

    public BookingController(FlightService flightService, BookingService bookingService, TicketService ticketService) {
        this.flightService = flightService;
        this.bookingService = bookingService;
        this.ticketService = ticketService;
    }

    private User currentUser(HttpServletRequest request) {
        return (User) request.getSession().getAttribute(AuthInterceptor.SESSION_USER);
    }

    @GetMapping("/new")
    public String bookingForm(@RequestParam Long flightId, Model model) {
        Flight flight = flightService.getById(flightId);
        model.addAttribute("flight", flight);
        if (!model.containsAttribute("journeyDate")) {
            model.addAttribute("journeyDate", "");
            model.addAttribute("numPassengers", "");
        }
        return "bookingForm";
    }

    @PostMapping("/new")
    public String submitBookingForm(@RequestParam Long flightId,
                                     @RequestParam String journeyDate,
                                     @RequestParam Integer numPassengers,
                                     HttpServletRequest request,
                                     Model model) {
        Flight flight = flightService.getById(flightId);
        model.addAttribute("flight", flight);
        model.addAttribute("journeyDate", journeyDate);
        model.addAttribute("numPassengers", numPassengers == null ? "" : numPassengers);

        LocalDate parsedDate;
        try {
            parsedDate = LocalDate.parse(journeyDate);
        } catch (DateTimeParseException | NullPointerException e) {
            model.addAttribute("formError", "Please enter a valid journey date.");
            return "bookingForm";
        }
        if (parsedDate.isBefore(LocalDate.now())) {
            model.addAttribute("formError", "Journey date cannot be in the past.");
            return "bookingForm";
        }
        if (numPassengers == null || numPassengers < 1 || numPassengers > 10) {
            model.addAttribute("formError", "Number of passengers must be between 1 and 10.");
            return "bookingForm";
        }

        int available = flightService.getAvailableSeats(flightId, parsedDate);
        if (available < numPassengers) {
            model.addAttribute("formError", "Only " + available + " seat(s) available on " + journeyDate + ".");
            return "bookingForm";
        }

        PendingBooking pending = new PendingBooking(flightId, parsedDate, numPassengers);
        request.getSession().setAttribute(PENDING_BOOKING, pending);
        return "redirect:/booking/passenger";
    }

    @GetMapping("/passenger")
    public String addPassengerForm(HttpServletRequest request, Model model) {
        PendingBooking pending = (PendingBooking) request.getSession().getAttribute(PENDING_BOOKING);
        if (pending == null) {
            return "redirect:/";
        }
        Flight flight = flightService.getById(pending.getFlightId());
        model.addAttribute("flight", flight);
        model.addAttribute("pending", pending);
        if (!model.containsAttribute("ticket")) {
            model.addAttribute("ticket", new Ticket());
        }
        return "addPassenger";
    }

    @PostMapping("/passenger")
    public String submitPassenger(@Valid @ModelAttribute("ticket") Ticket ticket,
                                   BindingResult bindingResult,
                                   HttpServletRequest request,
                                   Model model) {
        PendingBooking pending = (PendingBooking) request.getSession().getAttribute(PENDING_BOOKING);
        if (pending == null) {
            return "redirect:/";
        }
        if (bindingResult.hasErrors()) {
            model.addAttribute("flight", flightService.getById(pending.getFlightId()));
            model.addAttribute("pending", pending);
            return "addPassenger";
        }

        pending.getPassengers().add(ticket);

        if (pending.isComplete()) {
            User user = currentUser(request);
            Booking booking = bookingService.createBooking(
                    pending.getFlightId(), user.getUserId(), pending.getJourneyDate(), pending.getPassengers());
            request.getSession().removeAttribute(PENDING_BOOKING);
            return "redirect:/booking/confirmation/" + booking.getBookingId();
        }

        pending.setCurrentPassengerIndex(pending.getCurrentPassengerIndex() + 1);
        return "redirect:/booking/passenger";
    }

    @GetMapping("/confirmation/{bookingId}")
    public String confirmation(@PathVariable Long bookingId, HttpServletRequest request, Model model) {
        User user = currentUser(request);
        Booking booking = bookingService.getOwnedBooking(bookingId, user.getUserId());
        List<Ticket> tickets = ticketService.getTicketsForBooking(bookingId);
        model.addAttribute("booking", booking);
        model.addAttribute("tickets", tickets);
        return "bookingConfirmation";
    }
}
