package com.flightreservation.controller;

import com.flightreservation.exception.DuplicateFlightNumberException;
import com.flightreservation.model.Flight;
import com.flightreservation.service.BookingService;
import com.flightreservation.service.FlightService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final FlightService flightService;
    private final BookingService bookingService;

    public AdminController(FlightService flightService, BookingService bookingService) {
        this.flightService = flightService;
        this.bookingService = bookingService;
    }

    @GetMapping("/dashboard")
    public String dashboard() {
        return "adminDashboard";
    }

    @GetMapping("/flights/add")
    public String addFlightForm(Model model) {
        if (!model.containsAttribute("flight")) {
            model.addAttribute("flight", new Flight());
        }
        return "addFlight";
    }

    @PostMapping("/flights/add")
    public String addFlight(@Valid @ModelAttribute("flight") Flight flight,
                             BindingResult bindingResult,
                             RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "addFlight";
        }
        try {
            flightService.addFlight(flight);
        } catch (DuplicateFlightNumberException e) {
            bindingResult.rejectValue("flightNumber", "duplicate", e.getMessage());
            return "addFlight";
        }
        redirectAttributes.addFlashAttribute("flightAdded",
                "Flight " + flight.getFlightNumber() + " added successfully.");
        return "redirect:/admin/flights/add";
    }

    @GetMapping("/flights/view")
    public String viewFlights(@RequestParam(defaultValue = "upcoming") String tab, Model model) {
        List<Map<String, Object>> upcoming = bookingService.getJourneySummary(true);
        List<Map<String, Object>> completed = bookingService.getJourneySummary(false);
        model.addAttribute("upcoming", upcoming);
        model.addAttribute("completed", completed);
        model.addAttribute("activeTab", tab);
        model.addAttribute("currentDate", java.time.LocalDate.now());
        return "viewFlights";
    }
}
