package com.flightreservation.controller;

import com.flightreservation.interceptor.AuthInterceptor;
import com.flightreservation.model.Booking;
import com.flightreservation.model.Ticket;
import com.flightreservation.model.User;
import com.flightreservation.service.BookingService;
import com.flightreservation.service.TicketService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping("/user")
public class UserDashboardController {

    private final BookingService bookingService;
    private final TicketService ticketService;

    public UserDashboardController(BookingService bookingService, TicketService ticketService) {
        this.bookingService = bookingService;
        this.ticketService = ticketService;
    }

    private User currentUser(HttpServletRequest request) {
        return (User) request.getSession().getAttribute(AuthInterceptor.SESSION_USER);
    }

    @GetMapping("/dashboard")
    public String dashboard() {
        return "userDashboard";
    }

    @GetMapping("/bookings")
    public String myBookings(HttpServletRequest request, Model model) {
        User user = currentUser(request);
        List<Booking> bookings = bookingService.getBookingsForUser(user.getUserId());
        model.addAttribute("bookings", bookings);
        return "myBookings";
    }

    @PostMapping("/bookings/{bookingId}/cancel")
    public String cancelBooking(@PathVariable Long bookingId, HttpServletRequest request) {
        User user = currentUser(request);
        bookingService.cancelBooking(bookingId, user.getUserId());
        return "redirect:/user/bookings";
    }

    @PostMapping("/bookings/{bookingId}/tickets/{pnrNo}/cancel")
    public String cancelTicket(@PathVariable Long bookingId, @PathVariable Long pnrNo, HttpServletRequest request) {
        User user = currentUser(request);
        bookingService.cancelTicket(bookingId, pnrNo, user.getUserId());
        return "redirect:/user/bookings/" + bookingId + "/tickets";
    }

    @GetMapping("/bookings/{bookingId}/tickets")
    public String viewTickets(@PathVariable Long bookingId, HttpServletRequest request, Model model) {
        User user = currentUser(request);
        Booking booking = bookingService.getOwnedBooking(bookingId, user.getUserId());
        List<Ticket> tickets = ticketService.getTicketsForBooking(bookingId);
        model.addAttribute("booking", booking);
        model.addAttribute("tickets", tickets);
        return "viewTicket";
    }
}
