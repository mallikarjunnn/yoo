package com.flightreservation.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Serves the landing page. The actual flight search is handled by
 * FlightController, per Architecture.md's controller split.
 */
@Controller
public class HomeController {

    @GetMapping("/")
    public String home(Model model) {
        if (!model.containsAttribute("source")) {
            model.addAttribute("source", "");
            model.addAttribute("destination", "");
        }
        return "home";
    }
}
