package com.flightreservation.controller;

import com.flightreservation.model.Ticket;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Plain in-session holder for the multi-step Book Flight flow
 * (Booking Form -> Add Passenger x N -> Confirmation). Not persisted;
 * only the finished booking + tickets are written to the database.
 */
public class PendingBooking implements Serializable {

    private Long flightId;
    private LocalDate journeyDate;
    private int numPassengers;
    private int currentPassengerIndex = 1; // 1-based, for display "Passenger X of Y"
    private final List<Ticket> passengers = new ArrayList<>();

    public PendingBooking() {}

    public PendingBooking(Long flightId, LocalDate journeyDate, int numPassengers) {
        this.flightId = flightId;
        this.journeyDate = journeyDate;
        this.numPassengers = numPassengers;
    }

    public Long getFlightId() { return flightId; }
    public LocalDate getJourneyDate() { return journeyDate; }
    public int getNumPassengers() { return numPassengers; }
    public int getCurrentPassengerIndex() { return currentPassengerIndex; }
    public void setCurrentPassengerIndex(int currentPassengerIndex) { this.currentPassengerIndex = currentPassengerIndex; }
    public List<Ticket> getPassengers() { return passengers; }
    public boolean isComplete() { return passengers.size() >= numPassengers; }
}
