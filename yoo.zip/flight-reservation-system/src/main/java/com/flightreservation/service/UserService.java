package com.flightreservation.service;

import com.flightreservation.dao.UserDao;
import com.flightreservation.exception.DuplicateEmailException;
import com.flightreservation.exception.InvalidCredentialsException;
import com.flightreservation.model.User;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private final UserDao userDao;

    public UserService(UserDao userDao) {
        this.userDao = userDao;
    }

    /**
     * Passwords are stored as plain text (not hashed) at the project owner's explicit
     * request, so they stay directly readable in the `user` table for lookup/support
     * purposes without building a password-reset flow. This is a deliberate,
     * documented trade-off for this local training prototype - see Memory.md.
     */
    public User signUp(User user) {
        if (userDao.existsByEmail(user.getEmail())) {
            throw new DuplicateEmailException("An account with this email already exists.");
        }
        Long id = userDao.save(user);
        user.setUserId(id);
        user.setPassword(null); // clears it from this in-memory object only; the row in the DB stays plain text
        return user;
    }

    public User login(String email, String rawPassword) {
        User user = userDao.findByEmail(email)
                .orElseThrow(() -> new InvalidCredentialsException("Invalid email or password."));
        if (user.getPassword() == null || !user.getPassword().equals(rawPassword)) {
            throw new InvalidCredentialsException("Invalid email or password.");
        }
        user.setPassword(null); // don't keep it sitting in the HttpSession for the rest of the visit
        return user;
    }
}
