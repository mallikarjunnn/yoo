package com.flightreservation.service;

import com.flightreservation.dao.FlightDao;
import com.flightreservation.exception.DuplicateFlightNumberException;
import com.flightreservation.exception.ResourceNotFoundException;
import com.flightreservation.model.Flight;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class FlightService {

    private final FlightDao flightDao;

    public FlightService(FlightDao flightDao) {
        this.flightDao = flightDao;
    }

    public Flight addFlight(Flight flight) {
        if (flightDao.existsByFlightNumber(flight.getFlightNumber())) {
            throw new DuplicateFlightNumberException(
                    "Flight number '" + flight.getFlightNumber() + "' already exists.");
        }
        if (flight.getCapacity() == null) {
            flight.setCapacity(20); // default per brief: all flights run daily, capacity 20 by default
        }
        Long id = flightDao.save(flight);
        flight.setFlightId(id);
        return flight;
    }

    public List<Flight> searchFlights(String source, String destination) {
        return flightDao.searchByRoute(source.trim(), destination.trim());
    }

    public Flight getById(Long flightId) {
        return flightDao.findById(flightId)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found."));
    }

    public List<Flight> getAll() {
        return flightDao.findAll();
    }

    /**
     * Seats still available for a flight on a given journey date.
     * Flights run daily, so capacity is checked per specific date, not globally.
     */
    public int getAvailableSeats(Long flightId, LocalDate journeyDate) {
        Flight flight = getById(flightId);
        int booked = flightDao.getBookedSeats(flightId, journeyDate);
        return flight.getCapacity() - booked;
    }
}
