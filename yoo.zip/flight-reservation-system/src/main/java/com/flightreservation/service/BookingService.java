package com.flightreservation.service;

import com.flightreservation.dao.BookingDao;
import com.flightreservation.dao.TicketDao;
import com.flightreservation.exception.ResourceNotFoundException;
import com.flightreservation.exception.SeatUnavailableException;
import com.flightreservation.model.Booking;
import com.flightreservation.model.Flight;
import com.flightreservation.model.Ticket;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
public class BookingService {

    private final BookingDao bookingDao;
    private final TicketDao ticketDao;
    private final FlightService flightService;

    public BookingService(BookingDao bookingDao, TicketDao ticketDao, FlightService flightService) {
        this.bookingDao = bookingDao;
        this.ticketDao = ticketDao;
        this.flightService = flightService;
    }

    /**
     * Validates that enough seats remain on the given flight/date before the
     * Add Passenger flow starts. Throws SeatUnavailableException otherwise.
     */
    public void checkAvailability(Long flightId, LocalDate journeyDate, int numPassengers) {
        int available = flightService.getAvailableSeats(flightId, journeyDate);
        if (available < numPassengers) {
            throw new SeatUnavailableException(
                    "Only " + available + " seat(s) available on this date, but " +
                            numPassengers + " passenger(s) were requested.");
        }
    }

    /**
     * Finalizes a booking once all passengers have been collected: inserts the
     * booking row, then one ticket per passenger with a sequential seat number.
     * Runs as a single transaction so a partial booking is never persisted.
     */
    @Transactional
    public Booking createBooking(Long flightId, Long userId, LocalDate journeyDate, List<Ticket> passengers) {
        // Re-check availability at commit time in case of concurrent bookings
        checkAvailability(flightId, journeyDate, passengers.size());

        Flight flight = flightService.getById(flightId);

        Booking booking = new Booking();
        booking.setBookingDate(LocalDate.now());
        booking.setJourneyDate(journeyDate);
        booking.setSeats(passengers.size());
        booking.setTotalPrice(flight.getPricePerSeat() * passengers.size());
        booking.setStatus("BOOKED");
        booking.setFlightId(flightId);
        booking.setUserId(userId);

        Long bookingId = bookingDao.save(booking);
        booking.setBookingId(bookingId);

        int seatOffset = ticketDao.countSeatsTakenForFlightOnDate(flightId, journeyDate);
        int seatNum = seatOffset + 1;
        for (Ticket passenger : passengers) {
            passenger.setJourneyDate(journeyDate);
            passenger.setBookingId(bookingId);
            passenger.setSeatNo("A" + seatNum);
            passenger.setStatus("BOOKED");
            ticketDao.save(passenger);
            seatNum++;
        }
        return booking;
    }

    public List<Booking> getBookingsForUser(Long userId) {
        return bookingDao.findByUserId(userId);
    }

    public Booking getOwnedBooking(Long bookingId, Long userId) {
        Booking booking = bookingDao.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found."));
        if (!booking.getUserId().equals(userId)) {
            throw new ResourceNotFoundException("Booking not found.");
        }
        return booking;
    }

    @Transactional
    public void cancelBooking(Long bookingId, Long userId) {
        Booking booking = getOwnedBooking(bookingId, userId);
        if ("CANCELLED".equals(booking.getStatus())) {
            return; // already cancelled, nothing to do
        }
        bookingDao.updateStatus(bookingId, "CANCELLED");
        ticketDao.updateStatusByBookingId(bookingId, "CANCELLED");
    }

    /**
     * Cancels a single passenger's ticket within a multi-passenger booking,
     * without touching the other passengers' tickets or seats. If that was the
     * last active ticket on the booking, the booking itself is marked CANCELLED.
     */
    @Transactional
    public void cancelTicket(Long bookingId, Long pnrNo, Long userId) {
        getOwnedBooking(bookingId, userId); // verifies the booking belongs to this user
        Ticket ticket = ticketDao.findByPnrAndBookingId(pnrNo, bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Ticket not found."));
        if ("CANCELLED".equals(ticket.getStatus())) {
            return; // already cancelled, nothing to do
        }
        ticketDao.updateStatusByPnr(pnrNo, "CANCELLED");

        int remainingActive = ticketDao.countActiveTickets(bookingId);
        if (remainingActive == 0) {
            bookingDao.updateStatus(bookingId, "CANCELLED");
        }
    }

    public List<Map<String, Object>> getJourneySummary(boolean upcoming) {
        return bookingDao.getJourneySummary(upcoming);
    }
}
