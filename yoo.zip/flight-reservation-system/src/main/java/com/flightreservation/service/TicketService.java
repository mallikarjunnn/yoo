package com.flightreservation.service;

import com.flightreservation.dao.TicketDao;
import com.flightreservation.model.Ticket;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TicketService {

    private final TicketDao ticketDao;

    public TicketService(TicketDao ticketDao) {
        this.ticketDao = ticketDao;
    }

    public List<Ticket> getTicketsForBooking(Long bookingId) {
        return ticketDao.findByBookingId(bookingId);
    }
}
