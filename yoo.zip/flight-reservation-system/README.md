# Flight Reservation System

A Spring Core / Spring MVC / Spring JDBC flight booking application, built to the
Deloitte case-study brief. JSP + Spring Form Tag Library views, MySQL via `JdbcTemplate`
(no JPA/Hibernate), Java-based Spring config (no XML bean definitions, no Spring Boot).

## Prerequisites

- JDK 11+
- Maven 3.6+
- MySQL 8.x running locally (or reachable)

## 1. Set up the database

```bash
mysql -u root -p < db/schema.sql
```

This creates the `flight_reservation` database, all four tables, and seeds a handful
of sample flights (AI101, IN201, AI304, 6E505, SG220) so you can search/book immediately.

## 2. Configure the database connection

Edit `src/main/resources/application.properties`:

```properties
db.url=jdbc:mysql://localhost:3306/flight_reservation?useSSL=false&serverTimezone=UTC
db.username=root
db.password=root
```

## 3. Run it

**Option A — embedded Tomcat via Maven (fastest for local dev):**

```bash
mvn tomcat7:run
```

Then open http://localhost:8080/

**Option B — build a WAR and deploy to your own Tomcat:**

```bash
mvn clean package
# copy target/flight-reservation-system.war to <tomcat>/webapps/
```

## 4. Run the unit tests

```bash
mvn test
```

Covers Sign Up and Login (`UserServiceTest`, `AuthControllerTest`) per Milestone 7.

## Default accounts

There are no pre-seeded users — sign up as either role from the home page:
- Sign up with role **User** to search/book flights.
- Sign up with role **Admin** to add flights and view journey/revenue stats.

## What's implemented (all 8 milestones)

1. Home page, flight search, and results listing
2. Sign Up / Login (session-based, no Spring Security)
3. Book Flight: booking form -> add passenger (looped per passenger) -> confirmation
4. Admin: Add Flight, View Flights (Upcoming / Completed tabs with revenue stats)
5. User Dashboard: My Bookings (view tickets, cancel with seat release)
6. Centralized exception handling (`@ControllerAdvice` -> friendly `error.jsp`)
7. Unit tests for Sign Up and Login
8. (Push to your own GitHub repo — not something this assistant can do for you)

See `Memory.md` for the full decision/assumption log.
